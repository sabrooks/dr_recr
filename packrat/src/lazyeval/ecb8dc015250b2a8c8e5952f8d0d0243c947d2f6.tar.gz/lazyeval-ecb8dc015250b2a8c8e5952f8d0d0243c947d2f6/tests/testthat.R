library(testthat)
library(lazyeval)

test_check("lazyeval")
