addLast <- function( fun )
    .Defunct(new=paste(".Last <- lastAdd(", deparse(substitute(fun)), ")", sep=''),
             package='gtools'
             )
