#ifndef BOOM_UINT_HPP
#define BOOM_UINT_HPP
namespace BOOM{
  typedef unsigned int uint;
}
#endif
